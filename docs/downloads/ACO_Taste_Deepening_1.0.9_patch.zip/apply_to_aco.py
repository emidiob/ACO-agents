#!/usr/bin/env python3
"""Install original Taste Deepening into a *local* ACO 1.0.9 checkout.

Dry-run by default. --apply is required to make changes. Never commits/pushes.
Refuses to replace unknown destination files or overwrite altered insertion markers.
"""
from __future__ import annotations
import argparse
import hashlib
from pathlib import Path
import os
import shutil
import tempfile

ROOT = Path(__file__).resolve().parent
FILES = (
    "skills/aco-taste/scripts/aco_taste/deepening.py",
    "skills/aco-taste/scripts/deepen.py",
    "tests/test_taste_deepening.py",
    "docs/ACO-TASTE-DEEPENING.md",
)
MARKER = "<!-- ACO-TASTE-DEEPENING-110 -->"
BLOCKS = {
    "skills/aco-taste/SKILL.md": (
        "## Release acceptance",
        """## Deeper evidence tools — ACO Taste Deepening

For substantive exploratory visual work, use the *original* read-only/receipt-based
checks in [ACO Taste Deepening](../../docs/ACO-TASTE-DEEPENING.md):

- Before rendering competing directions, run
  `python3 skills/aco-taste/scripts/deepen.py variants --packet /path/to/directions.json`
  to reject palette-only alternatives and weak structural distinctions.
- Before applying project-specific preferences, run
  `python3 skills/aco-taste/scripts/deepen.py feedback --project /path/to/project --query 'relevant treatment'`
  and read the original reasons, including exceptions. No cross-project inference.
- For an iteration after real inspection, run
  `python3 skills/aco-taste/scripts/deepen.py cycle --packet /path/to/inspection.json`
  with observed before/after region/timecode and artifact hashes.
- For UI animation, run `python3 skills/aco-taste/scripts/deepen.py motion --packet /path/to/motion.json`
  before choosing animation details; actual playback and reduced-motion tests remain mandatory.

A green contract result is not a visually inspected result. All media output remains
subject to the existing seven-gate Taste protocol.

""",
    ),
    "skills/aco-taste/references/TASTE-PROTOCOL.md": (
        "## Review independence",
        """## Evidence-based deepening checks

When exploring 2–3 directions, reject merely recolored template variants by running
`deepen.py variants` on the concept packet, then compare *rendered* alternatives.
For a user preference, retrieve scoped reasons with `deepen.py feedback` before treating
feedback as a design constraint; conflicts and exceptions remain context-specific.
For revised visuals, record region/timecode, correction, observation and actual
before/after receipts with `deepen.py cycle`. For new UI motion, start with the
`deepen.py motion` necessity/frequency/accessibility gate. None of these commands
replaces the visual, functional or human judgment checks in gates 5–7.

""",
    ),
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def atomic_write(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def plan(checkout: Path):
    checkout = checkout.expanduser().resolve(strict=True)
    version = checkout / "VERSION"
    if not version.is_file() or version.read_text(encoding="utf-8").strip() != "1.0.9":
        raise ValueError("Expected local ACO VERSION 1.0.9; no write made")
    if not (checkout / "skills/aco-taste/scripts/aco_taste/__init__.py").is_file():
        raise ValueError("Cannot find the expected ACO Taste package; no write made")
    writes = []
    for relative in FILES:
        dest = checkout / relative
        source = ROOT / relative
        content = source.read_bytes()
        if dest.exists():
            if dest.is_symlink() or dest.read_bytes() != content:
                raise ValueError(f"Target exists with different content: {relative}; no write made")
            continue
        writes.append((dest, content))
    for relative, (anchor, block) in BLOCKS.items():
        dest = checkout / relative
        if dest.is_symlink() or not dest.is_file():
            raise ValueError(f"Missing/unsafe integration target: {relative}; no write made")
        current = dest.read_text(encoding="utf-8")
        if MARKER in current:
            # Refuse a partial or divergent previous install.
            if (MARKER + "\n" + block) not in current:
                raise ValueError(f"Existing integration differs: {relative}; no write made")
            continue
        if current.count(anchor) != 1:
            raise ValueError(f"Unique insertion anchor not found: {relative}; no write made")
        revised = current.replace(anchor, MARKER + "\n" + block + anchor)
        writes.append((dest, revised.encode("utf-8")))
    return writes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkout", help="Existing local ACO 1.0.9 repository root")
    parser.add_argument("--apply", action="store_true", help="Perform local writes (no git commit/push)")
    args = parser.parse_args()
    try:
        writes = plan(Path(args.checkout))
        for path, data in writes:
            print(f"{'WRITE' if args.apply else 'WOULD WRITE'} {path} [{digest(data)[:12]}]")
        if args.apply:
            for path, content in writes:
                atomic_write(path, content)
            print(f"Installed {len(writes)} files. Run: python3 -m unittest discover -s tests -p 'test_taste_deepening.py' -v")
        else:
            print(f"Dry run: {len(writes)} planned files, no writes. Pass --apply to install locally.")
        return 0
    except (ValueError, OSError) as exc:
        print(f"BLOCKED: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
